import logging
import asyncio
from datetime import datetime
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor

from sqlighter import SQLighter
#from hltv import Hltv


# Объект бота
bot = Bot(token="5029290279:AAGjn54yO1PgY9aWsGAPuk_U7hC0WCGkSL4")
# Диспетчер для бота
dp = Dispatcher(bot)
db=SQLighter('tb.db')

#sg=Hltv('lastkey.txt')

'''image = BytesIO()

#Фото надо отправить в виде файла
@dp.message_handler(content_types=['document'])
async def photo_handler(message: types.Message):
    bytes = message.document.thumb.download(destination=image)
    
    #Вывод байт-обьекта
    print(bytes.read())

    #тип данных в переменной - io.BytesIO
    await message.answer(type(image))'''

@dp.message_handler(commands=['subscribe'])
async def subscribe(message: types.Message):
    if (not db.subscriber_exists(message.from_user.id)):
        db.add_subscriber(message.from_user.id)
    else:
        db.update_subscription(message.from_user.id, True)

    await message.reply("Вы успешно подписались на рассылку!\nЖдите, скоро выйдут новые обзоры)")

@dp.message_handler(commands=['unsubscribe'])
async def unsubscribe(message: types.Message):
    if (not db.subscriber_exists(message.from_user.id)):
        db.add_subscriber(message.from_user.id, False)
        await message.reply("Сори но у тебя нет подписьки.")
    else:
        db.update_subscription(message.from_user.id, False)
        await message.reply("ну и уходи, чертила!")

# Хэндлер на команду /test1
@dp.message_handler(commands="test1")
async def cmd_test1(message: types.Message):
    await message.reply("Test 1")

@dp.message_handler(commands=['start'])
async def process_start_command(message: types.Message):
    await message.reply("Привет!\nНапиши мне что-нибудь!")

@dp.message_handler(commands=['help'])
async def process_help_command(message: types.Message):
    await message.reply("Напиши мне что-нибудь, и я отпрпавлю этот текст тебе в ответ!")

@dp.message_handler(commands=['give_site'])
async def give_my_site(message: types.Message):
    await message.reply("Держи ссылку на мой сайт: '...'")
    await bot.send_message(message.from_user.id, 'pravda ego eshe net v seti!') 

@dp.message_handler()
async def echo_message(msg: types.Message):
    await bot.send_message(msg.from_user.id, msg.text)



async def scheduled(wait_for):
    while True:
        await asyncio.sleep(wait_for)

        '''new_games = sg.new_games()

        if(new_games):
            new_games.reverse()
            for ng in new_games:
                nfo = sg.game.info(ng)

            subscriptions = db.get_subscriptions()

            with open(sg.download_image(nfo['image']), 'rb') as photo:
                for s in subscriptions:
                    await bot.send_photo(
                        s[1],
                        photo,
                        caption= nfo['title'] +"\n"+"Оценка"+nfo['score']+"\n"+nfo['excerpt']+"\n\n"+nfo['link'],
                        disable_notification = True
                    )
            sg.update_lastkey(nfo['id'])'''


        now = 'pidoras' #datetime.utcnow()
        await bot.send_message(958816179, f"{now}",disable_notification=True)

if __name__ == "__main__":
    #asyncio.get_event_loop().run_until_complete(scheduled(10))
    # Запуск бота
    executor.start_polling(dp)