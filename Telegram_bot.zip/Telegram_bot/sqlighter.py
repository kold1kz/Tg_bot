import sqlite3

from distlib import database


class SQLighter:

    def __init__(self, datebase_file):

        self.connection = sqlite3.connect(database)
        self.cursor =self.connection.cursor()

    def get_subscriptions(self, status= True):
        with self.connection:
            return self.cursor.execute("SELECT * FROM 'subscriptions' WHERE 'status' = ?", (status,)).fetchall()

    def subscriber_exists(self, user_id):
        with self.connection:
            result = self.cursor.execute("SELECT * FROM 'subscriptions' WHERE 'user_id' =?", (user_id,)).fetchall()
            return bool(len(result))

    def add_subscriber(self, user_id, status=True):
       with self.connection:
           return self.cursor.execute("INSERT INTO 'subscriptions' ('user_id', 'status') VALUES (?,?)", (user_id, status))

    def update_subscription(self, user_id, status):
          return self.cursor.execute("UPDATE 'subscriptions' SET 'status'=? WHERE 'user_id' =?",(status, user_id))


    def close(self):
        self.connection.close()